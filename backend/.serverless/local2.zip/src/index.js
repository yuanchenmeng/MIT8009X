const { connectToDatabase } = require('./db');

const express = require('express');
const cors = require('cors');
const serverless = require('serverless-http');
const app = express();

const allowedOrigins = [
    /^https:\/\/.*\.amplifyapp\.com$/, 
    "http://127.0.0.1:3000", 
    "http://localhost:3000"
];

app.use(express.json()); 

app.use(cors({
    origin: function (origin, callback) {
        if (!origin || allowedOrigins.some(item => {
            if (typeof item === 'string') {
                return item === origin;  // Exact string match
            }
            if (item instanceof RegExp) {
                return item.test(origin);  // Regex match
            }
            return false;
        })) {
            callback(null, true);  // Allow the request if it matches
        } else {
            callback(new Error('Not allowed by CORS'));  // Reject the request
        }
    },
    methods: ['GET', 'POST', 'PUT', 'DELETE'],  // Add any other methods you're using
    allowedHeaders: ['Content-Type', 'Authorization'],  // Add any other headers you might need
    credentials: true  // Enable cookies if required
}));

// Handle the preflight OPTIONS request
//app.options('*', (req, res) => {
//    //res.header('Access-Control-Allow-Origin', '*');
//    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
//    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
//    res.sendStatus(200);  // Respond with status 200 for preflight
//});

app.get('/', (req, res) => {
    res.send('Hello World!ooo!');
});

app.get('/ptest', async (req, res) => {
    try {
        const connection = await connectToDatabase(); // Connect to the database
        const [rows] = await connection.execute('SELECT NOW() AS currentTime'); // Example query
        res.send({ message: 'Hello World! @ !', dbTime: rows[0].currentTime });
    } catch (error) {
        console.error('Error connecting to the database:', error.message);
        res.status(500).send({ error: 'Database connection failed', details: error.message });
    }
});






// CRUD Operations for my_user table

// 1. Create a new user
app.post('/users', async (req, res) => {
    const { text, counter } = req.body;
    if (!text || typeof counter === 'undefined') {
        return res.status(400).send({ error: 'Invalid input: text and counter are required' });
    }
    try {
        const connection = await connectToDatabase();
        const [result] = await connection.execute(
            'INSERT INTO my_user (text, counter) VALUES (?, ?)',
            [text, counter]
        );
        res.status(201).send({ message: 'User created successfully', uid: result.insertId });
    } catch (error) {
        console.error('Error creating user:', error.message);
        res.status(500).send({ error: 'Failed to create user', details: error.message });
    }
});

// 2. Read all users
app.get('/users', async (req, res) => {
    try {
        const connection = await connectToDatabase();
        const [rows] = await connection.execute('SELECT * FROM my_user');
        res.send(rows);
    } catch (error) {
        console.error('Error retrieving users:', error.message);
        res.status(500).send({ error: 'Failed to retrieve users', details: error.message });
    }
});

// 3. Update a user by ID
app.put('/users/:uid', async (req, res) => {
    const { uid } = req.params;
    const { text, counter } = req.body;

    if (!text && typeof counter === 'undefined') {
        return res.status(400).send({ error: 'Invalid input: at least one field (text or counter) is required' });
    }

    try {
        const connection = await connectToDatabase();
        const [result] = await connection.execute(
            'UPDATE my_user SET text = COALESCE(?, text), counter = COALESCE(?, counter) WHERE uid = ?',
            [text, counter, uid]
        );

        if (result.affectedRows === 0) {
            return res.status(404).send({ error: 'User not found' });
        }

        res.send({ message: 'User updated successfully' });
    } catch (error) {
        console.error('Error updating user:', error.message);
        res.status(500).send({ error: 'Failed to update user', details: error.message });
    }
});

// 4. Delete a user by ID
app.delete('/users/:uid', async (req, res) => {
    const { uid } = req.params;

    try {
        const connection = await connectToDatabase();
        const [result] = await connection.execute('DELETE FROM my_user WHERE uid = ?', [uid]);

        if (result.affectedRows === 0) {
            return res.status(404).send({ error: 'User not found' });
        }

        res.send({ message: 'User deleted successfully' });
    } catch (error) {
        console.error('Error deleting user:', error.message);
        res.status(500).send({ error: 'Failed to delete user', details: error.message });
    }
});







const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

module.exports.handler = serverless(app);